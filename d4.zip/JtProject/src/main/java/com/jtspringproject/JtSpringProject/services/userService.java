package com.jtspringproject.JtSpringProject.services;

import com.jtspringproject.JtSpringProject.models.*;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jtspringproject.JtSpringProject.dao.userDao;
import com.jtspringproject.JtSpringProject.models.User;

@Service
public class userService {
	@Autowired
	private userDao userdao=new userDao();

	private User currentUser;

	public List<User> getUsers(){
		return this.userdao.getAllUser();
	}
	
	public User addUser(User user) {
		User newUser = this.userdao.saveUser(user);
		this.currentUser = newUser;
		return newUser;
	}
	public User checkLogin(String username,String password) {
		User loggedInUser = this.userdao.getUser(username, password);
		this.currentUser = loggedInUser;
		return loggedInUser;
	}
	public User getCurrentUser() {
		return this.currentUser;
	}

	public User updateUserProfile(User user){
		userdao=new userDao();
		if(userdao.saveUserProfile(user, currentUser) == null){
			return null;
		}
		currentUser = user;
		return currentUser;
	}

}
