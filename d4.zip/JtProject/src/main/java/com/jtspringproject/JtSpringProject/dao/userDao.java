package com.jtspringproject.JtSpringProject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.List;

import javax.persistence.NoResultException;
import javax.sound.midi.Soundbank;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jtspringproject.JtSpringProject.models.User;


@Repository
public class userDao {
	@Autowired
    private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory = sf;
    }
   @Transactional
    public List<User> getAllUser() {
        Session session = this.sessionFactory.getCurrentSession();
		List<User>  userList = session.createQuery("from CUSTOMER").list();
        return userList;
    }
    @Transactional
	public User saveUser(User user) {
		this.sessionFactory.getCurrentSession().saveOrUpdate(user);
		System.out.println("User added" + user.getId());
        return user;
	}
	@Transactional
	public User saveUserProfile(User user, User currentUser) {
		if(this.sessionFactory!=null) {
			Session session = this.sessionFactory.getCurrentSession();
			String updateQuery = "UPDATE CUSTOMER SET username = :newUsername, email = :newEmail, password = :newPassword, address = :newAddress WHERE username = :oldUsername";

			Query query = session.createSQLQuery(updateQuery)
					.setParameter("newUsername", user.getUsername())
					.setParameter("newEmail", user.getEmail())
					.setParameter("newPassword", user.getPassword())
					.setParameter("newAddress", user.getAddress())
					.setParameter("oldUsername", currentUser.getUsername());

			int result = query.executeUpdate();

			if (result > 0) {
				System.out.println("User profile updated for username: " + currentUser.getUsername());
				return user;
			} else {
				// Handle the case where the update did not occur
				System.out.println("User not found or update failed for username: " + currentUser.getUsername());
				return null;
			}
		}else {
			return null;
		}

	}


	//    public User checkLogin() {
//    	this.sessionFactory.getCurrentSession().
//    }
    @Transactional
    public User getUser(String username,String password) {
		User u=new User();
		String displayusername, displaypassword, displayemail, displayaddress;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommjava", "root", "VIVOY15!");
			PreparedStatement stmt = con.prepareStatement("select * from customer where username =? and password =?" + ";");
			stmt.setString(1,username );
			stmt.setString(2,password);
			ResultSet rst = stmt.executeQuery();
			if(rst.next()){
				int userid = rst.getInt(1);
				u.setId(userid);
				u.setUsername( rst.getString(6));
				u.setEmail( rst.getString(3));
				u.setPassword( rst.getString(4));
				u.setAddress(rst.getString(2));
			}
		} catch (Exception se){
			System.out.println("Exception:" + se);
		}
		return u;
    }
}
